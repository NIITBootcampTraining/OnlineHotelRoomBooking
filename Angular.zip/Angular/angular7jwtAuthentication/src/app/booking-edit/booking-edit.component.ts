import { Component, OnInit } from '@angular/core';
import { BookingService } from '../_services/booking.service';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Customer } from '../_models/customer';
import { Booking } from '../_models/booking';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-booking-edit',
  templateUrl: './booking-edit.component.html',
  styleUrls: ['./booking-edit.component.css'],
  providers:[BookingService]
})
export class BookingEditComponent implements OnInit {
  htForm: FormGroup;
  id:number;
  booking:Booking = new Booking();
  customerList: Customer[];

  constructor(private _ht: BookingService, private route: ActivatedRoute, private router:Router,private fb: FormBuilder) { this.createForm(); }

  ngOnInit() {
    this. getedit();
    this.getAllCustomers();
   
  }

  getedit(){
    this.route.params.subscribe(param =>{
      this.id = +param['id'];
      this._ht.getBookingsById(this.id).subscribe(result => {
        this.booking = result;
      })
    })
  }

  createForm() {
    this.htForm = this.fb.group({
      totalAmount: ['', Validators.required],
      bookingDate: ['', Validators.required],
      checkIn: ['', Validators.required],
      checkOut: ['', Validators.required],
      customerFirstName: ['', Validators.required]

    });
  }
  
  getAllCustomers() {
    this._ht.getCustomers().subscribe(result => {
      this.customerList = result;
      console.log(this.customerList);
    })
  } 

  editExistingbooking() {
    this._ht.editBooking(this.id,this.booking).subscribe(result => {
      console.log('booking Updated Successfully');
      this.router.navigate(['/booking']);
    })
  }
}
