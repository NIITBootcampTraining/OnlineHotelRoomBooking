import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { BookingEditComponent } from './booking-edit.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { Booking } from '../_models/booking';
import { BookingService } from '../_services/booking.service';


describe('Testing Booking-Edit Component', () => {

    let component: BookingEditComponent;
    let fixture: ComponentFixture<BookingEditComponent>;
    let booking = new Booking()
    {
            booking.bookingId = 1,
            booking.totalAmount = 12000,
            booking.customerId = 50

    }

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [BookingEditComponent],
            imports: [RouterTestingModule, HttpClientModule, ReactiveFormsModule],
            providers: [BookingService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BookingEditComponent);
        component = fixture.componentInstance;
    })

    it('Should create', async(() => {
        expect(component).toBeTruthy();
    }));

    it('Edit Booking', async(inject([BookingService], (BookingService) => {
        BookingService.editBooking(1, booking).subscribe(result => {
            console.log("Edited!!");
        })
    })))

})