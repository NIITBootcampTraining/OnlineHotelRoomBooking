import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Hoteltype } from '../_models/hoteltype';
import { Hotel } from '../_models/hotel';
import { HotelService } from '../_services/hotel.service';

@Component({
  selector: 'app-hotel-add',
  templateUrl: './hotel-add.component.html',
  styleUrls: ['./hotel-add.component.css'],
  providers:[HotelService]
})
export class HotelAddComponent implements OnInit {

  htForm: FormGroup;
  hotel:Hotel=new Hotel();
  hoteltypeList: Hoteltype[];

  constructor(private _ht:HotelService, private router:Router, private fb: FormBuilder) 
  { 
    this.createForm();
  }

  ngOnInit() {
    this.getAllHotelTypes();
  }
  
  getAllHotelTypes() {
    this._ht.getHoteltypes().subscribe(result => {
      this.hoteltypeList = result;
      console.log(this.hoteltypeList);
    })
  }

  createForm() {
    this.htForm = this.fb.group({
      hotelName: ['', Validators.required],
      hotelDescription: ['', Validators.required],
      hotelAddress: ['', Validators.required],
      hotelDistrict: ['', Validators.required],
      hotelCity: ['', Validators.required],
      hotelState: ['', Validators.required],
      hotelCountry: ['', Validators.required],
      hotelEmailId: ['', Validators.required],
      hotelRating: ['', Validators.required],
      hotelImage: ['', Validators.required],
      hotelContactNumber: ['', Validators.required],
      hotelTypeName: ['', Validators.required]

    });
  }

  addNewHotel(){
    this._ht.addHotel(this.hotel).subscribe(result=>{
      console.log(result);
      console.log("Hotel Added Succesfully!!");
      this.router.navigate(['/hotel']);
    })
  }
}
