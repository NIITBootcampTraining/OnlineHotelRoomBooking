import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { HotelAddComponent } from './hotel-add.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { Hotel } from '../_models/hotel';
import { HotelService } from '../_services/hotel.service';


describe('Testing Hotel-Add Component', () => {

    let component: HotelAddComponent;
    let fixture: ComponentFixture<HotelAddComponent>;
    let hotel = new Hotel()
    {
      
        hotel.hotelName = 'The Taj',
        hotel.hotelDescription = 'Good',
        hotel.hotelAddress = '123 A',
        hotel.hotelDistrict = 'Begu Sarai',
        hotel.hotelCity = 'Luknow',
        hotel.hotelState = 'UP',
        hotel.hotelCountry = 'India',
        hotel.hotelEmailId = 'abc@gmail.com',  
        hotel.hotelRating = 5,
        hotel.hotelContactNumber = 12365478,
        hotel.hotelTypeId = 1

    }

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [HotelAddComponent],
            imports: [RouterTestingModule, HttpClientModule, ReactiveFormsModule],
            providers: [HotelService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HotelAddComponent);
        component = fixture.componentInstance;
    })

    it('Should create', async(() => {
        expect(component).toBeTruthy();
    }));

    // it('Add Hotel', async(inject([HotelService], (hotelService => {
    //     hotelService.addHotel(hotel).subscribe(result => {
    //         console.log('Hotel Added Successfully');
    //     })
    // }))))

})