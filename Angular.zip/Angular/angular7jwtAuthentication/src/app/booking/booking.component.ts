import { Component, OnInit } from '@angular/core';
import { Booking } from '../_models/booking';
import { BookingService } from '../_services/booking.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css'],
  providers:[BookingService]
})
export class BookingComponent implements OnInit {

  bookingList: Booking[];

  constructor(private _h :BookingService) { }
  
  ngOnInit() {
    this.getAllBookings();
  }

  getAllBookings() {
    this._h.getBookings().subscribe(result => {
      this.bookingList = result;
      console.log(this.bookingList);
    })
  }

  deleteExistingBooking(id: number) {
    this._h.deleteBooking(id).subscribe(result => {
      console.log("Booking is deleted succesfully!!");
      this.getAllBookings();
    })

  }

}
