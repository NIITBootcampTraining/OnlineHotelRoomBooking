import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { BookingComponent } from './booking.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { BookingService } from '../_services/booking.service';


describe('Testing Booking Component', () => {

    let component: BookingComponent;
    let fixture: ComponentFixture<BookingComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [BookingComponent],
            imports: [RouterTestingModule, HttpClientModule],
            providers: [BookingService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BookingComponent);
        component = fixture.componentInstance;
    })

    it('Should create', async(() => {
        expect(component).toBeTruthy();
    }))

    // it('retrieve all the booking', async(inject([BookingService],(BookingService)=>{
    //     BookingService.getBookings().subscribe(result => {
    //         expect(result.length).toEqual(2);
    //     })
    // })))
})