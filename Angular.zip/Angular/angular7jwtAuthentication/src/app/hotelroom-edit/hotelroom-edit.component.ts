import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route } from '@angular/router';

import {Router} from '@angular/router';

import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HotelroomService } from '../_services/hotelroom.service';
import { Hotel } from '../_models/hotel';
import { Hotelroom } from '../_models/hotelroom';

@Component({
  selector: 'app-hotelroom-edit',
  templateUrl: './hotelroom-edit.component.html',
  styleUrls: ['./hotelroom-edit.component.css'],
  providers: [HotelroomService]
})
export class HotelroomEditComponent implements OnInit {

  htForm: FormGroup;
  id:number;
  hotelroom:Hotelroom= new Hotelroom();
  hotelList:Hotel[];

  constructor(private _ht: HotelroomService, private route: ActivatedRoute, private router:Router, private fb: FormBuilder) 
  { this.createForm(); }

  ngOnInit() {
    this. getedit();
    this.getAllHotels();
  }

  getedit(){
    this.route.params.subscribe(param =>{
      this.id = +param['id'];
      this._ht.getHotelroomsById(this.id).subscribe(result => {
        this.hotelroom = result;
      })
    })
  }

  createForm() {
    this.htForm = this.fb.group({
      roomType: ['', Validators.required],
      roomDescription: ['', Validators.required],
      roomPrice: ['', Validators.required],
      roomImage: ['', Validators.required],
      hotelName: ['', Validators.required]
    });
  }
  getAllHotels() {
    this._ht.getHotels().subscribe(result => {
      this.hotelList = result;
      console.log(this.hotelList);
    })
  }


  editExistingHotelRoom() {
    this._ht.editHotelRoom(this.id,this.hotelroom).subscribe(result => {
      console.log('HotelRoom Updated Successfully');
      this.router.navigate(['/hotelroom']);
    })
  }

}
