import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { HotelroomEditComponent } from './hotelroom-edit.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { Hotelroom } from '../_models/hotelroom';
import { HotelroomService } from '../_services/hotelroom.service';


describe('Testing Hotelroom-Edit Component', () => {

    let component: HotelroomEditComponent;
    let fixture: ComponentFixture<HotelroomEditComponent>;
    let hotelroom = new Hotelroom()
    {
            hotelroom.roomId = 4,
            hotelroom.roomType = "Single1",
            hotelroom.roomDescription = "abc",
            hotelroom.roomPrice = 10000,
            hotelroom.roomImage = "abcd",
            hotelroom.hotelId = 2

    };

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [HotelroomEditComponent],
            imports: [RouterTestingModule, HttpClientModule, ReactiveFormsModule],
            providers: [HotelroomService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HotelroomEditComponent);
        component = fixture.componentInstance;
    })

    it('Should create', async(() => {
        expect(component).toBeTruthy();
    }));

    it('Edit HotelRooms', async(inject([HotelroomService], (HotelroomService) => {
        HotelroomService.editHotelRoom(4, hotelroom).subscribe(result => {
            console.log("Edited!!");
        })
    })))

})