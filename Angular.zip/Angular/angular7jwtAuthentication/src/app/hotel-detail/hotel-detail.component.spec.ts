import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { HotelDetailComponent } from './hotel-detail.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { HotelService } from '../_services/hotel.service';


describe('Testing HotelDetail Component', () => {
    let component: HotelDetailComponent;
    let fixture: ComponentFixture<HotelDetailComponent>;


    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [HotelDetailComponent],
            imports: [RouterTestingModule, HttpClientModule, ReactiveFormsModule],
            providers: [HotelService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HotelDetailComponent);
        component = fixture.componentInstance;
    })

    it('should create', () => {

        expect(component).toBeTruthy();

    });

    it('retrives the Hotel by specific id', async(inject([HotelService], (hotelService) => {
        hotelService.getHotelsById(5).subscribe(result => {
            console.log('Get the hotel by Id');
        })
    })
    ))

})