import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router"
import { Hotel } from '../_models/hotel';
import { Hoteltype } from '../_models/hoteltype';
import { HoteltypeService } from '../_services/hoteltype.service';
import { HotelService } from '../_services/hotel.service';

@Component({
  selector: 'app-hotel-detail',
  templateUrl: './hotel-detail.component.html',
  styleUrls: ['./hotel-detail.component.css'],
  providers: [HotelService,HoteltypeService]
})
export class HotelDetailComponent implements OnInit {

  id: number;
  hotel:Hotel = new Hotel();
  htypeid:number;
  htype:Hoteltype=new Hoteltype();

  constructor(private route: ActivatedRoute,
    private _ht: HotelService,private _h:HoteltypeService, private router:Router) { }

  ngOnInit() {
       this.route.params.subscribe(param => {
       this.id = +param['id'];
       this._ht.getHotelsById(this.id).subscribe(result => {
       this.hotel=result;

       this.htypeid=this.hotel.hotelTypeId;
       this._h.getHoteltypesById(this.htypeid).subscribe(result1 => {
       this.htype=result1;
       })
      });
    });
  }

  deleteExistingHotel(id: number) {
    this._ht.deleteHotel(id).subscribe(result => {
      console.log("Hotel is deleted succesfully!!");
      this.router.navigate(['/hotel']);
    })


  }
}
