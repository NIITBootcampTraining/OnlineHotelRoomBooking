import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route } from '@angular/router';
import {Router} from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Hotel } from '../_models/hotel';
import { Hoteltype } from '../_models/hoteltype';
import { HotelService } from '../_services/hotel.service';

@Component({
  selector: 'app-hotel-edit',
  templateUrl: './hotel-edit.component.html',
  styleUrls: ['./hotel-edit.component.css'],
  providers: [HotelService]
})
export class HotelEditComponent implements OnInit {

  htForm: FormGroup;
  id:number;
  hotel:Hotel = new Hotel();
  hoteltypeList: Hoteltype[];

  constructor(private _ht: HotelService, private route: ActivatedRoute, private router:Router,private fb: FormBuilder) { this.createForm(); }

  ngOnInit() {
    this. getedit();
    this.getAllHotelTypes();
   
  }

  getedit(){
    this.route.params.subscribe(param =>{
      this.id = +param['id'];
      this._ht.getHotelsById(this.id).subscribe(result => {
        this.hotel = result;
      })
    })
  }

  createForm() {
    this.htForm = this.fb.group({
      hotelName: ['', Validators.required],
      hotelDescription: ['', Validators.required],
      hotelAddress: ['', Validators.required],
      hotelDistrict: ['', Validators.required],
      hotelCity: ['', Validators.required],
      hotelState: ['', Validators.required],
      hotelCountry: ['', Validators.required],
      hotelEmailId: ['', Validators.required],
      hotelRating: ['', Validators.required],
      hotelImage: ['', Validators.required],
      hotelContactNumber: ['', Validators.required],
      hotelTypeName: ['', Validators.required]

    });
  }
  
  getAllHotelTypes() {
    this._ht.getHoteltypes().subscribe(result => {
      this.hoteltypeList = result;
      console.log(this.hoteltypeList);
    })
  } 

  editExistingHotel() {
    this._ht.editHotel(this.id,this.hotel).subscribe(result => {
      console.log('Hotel Updated Successfully');
      this.router.navigate(['/hotel']);
    })
  }
}
