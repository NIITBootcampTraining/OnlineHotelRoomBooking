import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { HotelEditComponent } from './hotel-edit.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { Hotel } from '../_models/hotel';
import { HotelService } from '../_services/hotel.service';


describe('Testing Hotel-Edit Component', () => {

    let component: HotelEditComponent;
    let fixture: ComponentFixture<HotelEditComponent>;
    let hotel = new Hotel()
    {
            hotel.hotelId = 7,
            hotel.hotelName = 'The Taj',
            hotel.hotelDescription = 'Good',
            hotel.hotelAddress = '123 A',
            hotel.hotelDistrict = 'Begu Sarai',
            hotel.hotelCity = 'Luknow',
            hotel.hotelState = 'UP',
            hotel.hotelCountry = 'India',
            hotel.hotelEmailId = 'abc@gmail.com',  
            hotel.hotelRating = 5,
            hotel.hotelContactNumber = 12365478,
            hotel.hotelTypeId = 1

    }

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [HotelEditComponent],
            imports: [RouterTestingModule, HttpClientModule, ReactiveFormsModule],
            providers: [HotelService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HotelEditComponent);
        component = fixture.componentInstance;
    })

    it('Should create', async(() => {
        expect(component).toBeTruthy();
    }));

    it('Edit Hotel', async(inject([HotelService], (HotelService) => {
        HotelService.editHotel(7, hotel).subscribe(result => {
            console.log("Edited!!");
        })
    })))

})