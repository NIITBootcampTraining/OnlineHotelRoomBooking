import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home';
import { LoginComponent } from './login';
import { AuthGuard } from './_guards';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { HoteltypeComponent } from './hoteltype/hoteltype.component';
import { HoteltypeAddComponent } from './hoteltype-add/hoteltype-add.component';
import { HoteltypeEditComponent } from './hoteltype-edit/hoteltype-edit.component';
import { HoteltypedetailComponent } from './hoteltypedetail/hoteltypedetail.component';
import { HotelComponent } from './hotel/hotel.component';
import { HotelDetailComponent } from './hotel-detail/hotel-detail.component';
import { HotelAddComponent } from './hotel-add/hotel-add.component';
import { HotelEditComponent } from './hotel-edit/hotel-edit.component';
import { HotelroomComponent } from './hotelroom/hotelroom.component';
import { HotelroomDetailComponent } from './hotelroom-detail/hotelroom-detail.component';
import { HotelroomAddComponent } from './hotelroom-add/hotelroom-add.component';
import { HotelroomEditComponent } from './hotelroom-edit/hotelroom-edit.component';
import { RoomfacilityComponent } from './roomfacility/roomfacility.component';
import { RoomfacilityDetailComponent } from './roomfacility-detail/roomfacility-detail.component';
import { RoomfacilityAddComponent } from './roomfacility-add/roomfacility-add.component';
import { RoomfacilityEditComponent } from './roomfacility-edit/roomfacility-edit.component';
import { CustomerComponent } from './customer/customer.component';
import { CustomerDetailComponent } from './customer-detail/customer-detail.component';
import { CustomerEditComponent } from './customer-edit/customer-edit.component';
import { BookingComponent } from './booking/booking.component';
import { BookingDetailComponent } from './booking-detail/booking-detail.component';
import { BookingEditComponent } from './booking-edit/booking-edit.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentDetailComponent } from './payment-detail/payment-detail.component';

const appRoutes: Routes = [
    {
        path: '',
        component: HomeComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: 'about',
        component: AboutComponent,
        canActivate:[AuthGuard]
    },

    {
        path: 'contact',
        component: ContactComponent,
        canActivate:[AuthGuard]
    },
    { path: 'hoteltype', component: HoteltypeComponent , canActivate:[AuthGuard] },
    { path: 'hoteltypedetail/:id', component: HoteltypedetailComponent, canActivate:[AuthGuard] },
    { path: 'hoteltype-add', component: HoteltypeAddComponent, canActivate:[AuthGuard] },
    { path: 'hoteltype-edit/:id', component: HoteltypeEditComponent, canActivate:[AuthGuard] },
    { path: 'hotel', component: HotelComponent, canActivate:[AuthGuard]  },
    { path: 'hotel-detail/:id', component: HotelDetailComponent, canActivate:[AuthGuard] },
    { path: 'hotel-add', component: HotelAddComponent , canActivate:[AuthGuard] },
    { path: 'hotel-edit/:id', component: HotelEditComponent , canActivate:[AuthGuard] },
    { path: 'hotelroom', component: HotelroomComponent },
    { path: 'hotelroom-detail/:id', component: HotelroomDetailComponent, canActivate:[AuthGuard]  },
    { path: 'hotelroom-add', component:HotelroomAddComponent, canActivate:[AuthGuard]  },
    { path: 'hotelroom-edit/:id', component: HotelroomEditComponent, canActivate:[AuthGuard] },
    { path: 'roomfacility', component: RoomfacilityComponent, canActivate:[AuthGuard]  },
    { path: 'roomfacility-detail/:id', component:RoomfacilityDetailComponent, canActivate:[AuthGuard] },
    { path: 'roomfacility-add', component:RoomfacilityAddComponent, canActivate:[AuthGuard]  },
    { path: 'roomfacility-edit/:id', component: RoomfacilityEditComponent, canActivate:[AuthGuard] },
    { path: 'customer', component: CustomerComponent, canActivate:[AuthGuard]  },
    { path: 'customer-detail/:id', component:CustomerDetailComponent, canActivate:[AuthGuard] },
    { path: 'customer-edit/:id', component: CustomerEditComponent, canActivate:[AuthGuard] },
    { path: 'booking', component: BookingComponent, canActivate:[AuthGuard]  },
    { path: 'booking-detail/:id', component:BookingDetailComponent, canActivate:[AuthGuard] },
    { path: 'booking-edit/:id', component: BookingEditComponent, canActivate:[AuthGuard] },
    { path: 'payment', component: PaymentComponent, canActivate:[AuthGuard]  },
    { path: 'payment-detail/:id', component:PaymentDetailComponent, canActivate:[AuthGuard] },
    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

export const routing = RouterModule.forRoot(appRoutes);