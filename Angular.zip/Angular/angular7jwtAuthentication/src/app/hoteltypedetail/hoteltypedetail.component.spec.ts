import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import{HoteltypedetailComponent} from './hoteltypedetail.component';
import{RouterTestingModule} from'@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { HoteltypeService } from '../_services/hoteltype.service';


describe('Testing HoteltypeDetail Component', () => {
    let component: HoteltypedetailComponent;
    let fixture: ComponentFixture<HoteltypedetailComponent>;


    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [HoteltypedetailComponent],
            imports:[RouterTestingModule,HttpClientModule,ReactiveFormsModule],
            providers:[HoteltypeService]
        }).compileComponents();

    }));

    beforeEach(()=>{
        fixture=TestBed.createComponent(HoteltypedetailComponent);
        component=fixture.componentInstance;
    })

    it('should create', () => {
      
      expect(component).toBeTruthy();

    });

    it('retrives the Hoteltype by specific id',async(inject([HoteltypeService],(hoteltypeService)=>{
        hoteltypeService.getHoteltypesById(3).subscribe(result=>{
           console.log('Get the hoteltype by Id');
        })
  })
  ))

})