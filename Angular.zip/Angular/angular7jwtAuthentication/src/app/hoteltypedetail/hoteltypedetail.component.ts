import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router"
import { HoteltypeService } from '../_services/hoteltype.service';
import { Hoteltype } from '../_models/hoteltype';


@Component({
  selector: 'app-hoteltypedetail',
  templateUrl: './hoteltypedetail.component.html',
  styleUrls: ['./hoteltypedetail.component.css'],
  providers: [HoteltypeService]
})
export class HoteltypedetailComponent implements OnInit {

  id: number;
  hoteltype:Hoteltype= new Hoteltype();

  constructor(private route: ActivatedRoute,
    private _ht: HoteltypeService, private router:Router) { }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this._ht.getHoteltypesById(this.id).subscribe(result => {
       this.hoteltype=result;
      })
    });
  }

  deleteExistingHotelType(id: number) {
    this._ht.deleteHotelType(id).subscribe(result => {
      console.log("HotelType is deleted succesfully!!");
      this.router.navigate(['/hoteltype']);
    })

  }
}
