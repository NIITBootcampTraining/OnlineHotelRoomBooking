import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactComponent } from './contact.component';

describe('Testing Contact Component', () => {

    let component: ContactComponent;
    let fixture: ComponentFixture<ContactComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ContactComponent],
            imports: [],
            providers: []
        }).compileComponents();

    }));

    beforeEach(()=>{
        fixture=TestBed.createComponent(ContactComponent);
        component=fixture.componentInstance;
    })

    it('Should create', async(() => {
        expect(component).toBeTruthy();
    }))

    
    it('Testing Addition', async(() => {
        expect(component.add(1,2)).toEqual(3);
    }))

    it('Should render h2 tag', async(() => {
        const compiled= fixture.debugElement.nativeElement;
        expect(compiled.querySelector('h2').textContent).toContain('Contact Page');
    }))

    it('Should render p tag', async(() => {
        const compiled= fixture.debugElement.nativeElement;
        expect(compiled.querySelector('p').textContent).toContain('contact works!');
    }))
})