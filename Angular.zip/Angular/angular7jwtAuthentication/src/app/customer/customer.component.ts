import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../_services/customer.service';
import { Customer } from '../_models/customer';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css'],
  providers:[CustomerService]
})
export class CustomerComponent implements OnInit {

  customerList: Customer[];

  constructor(private _h :CustomerService) { }
  
  ngOnInit() {
    this.getAllCustomers();
  }

  getAllCustomers() {
    this._h.getCustomers().subscribe(result => {
      this.customerList = result;
      console.log(this.customerList);
    })
  }

  deleteExistingCustomer(id: number) {
    this._h.deleteCustomer(id).subscribe(result => {
      console.log("Customer is deleted succesfully!!");
      this.getAllCustomers();
    })

  }
}
