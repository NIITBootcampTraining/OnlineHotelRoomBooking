import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { CustomerComponent } from './customer.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { CustomerService } from '../_services/customer.service';


describe('Testing Customer Component', () => {

    let component: CustomerComponent;
    let fixture: ComponentFixture<CustomerComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [CustomerComponent],
            imports: [RouterTestingModule, HttpClientModule],
            providers: [CustomerService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CustomerComponent);
        component = fixture.componentInstance;
    })

    it('Should create', async(() => {
        expect(component).toBeTruthy();
    }))

    // it('retrieve all the Customers', async(inject([CustomerService],(CustomerService)=>{
    //     CustomerService.getCustomers().subscribe(result => {
    //         expect(result.length).toEqual(2);
    //     })
    // })))
})