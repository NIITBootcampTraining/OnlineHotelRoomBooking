import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Hotelroom } from '../_models/hotelroom';
import { Hotel } from '../_models/hotel';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable()
export class HotelroomService{

  constructor(private _http: HttpClient) { }


  getHotelrooms(): Observable<Hotelroom[]> {
    return this._http.get<Hotelroom[]>("http://localhost:61076/api/hotelroom");
  }

  getHotels(): Observable<Hotel[]> {
    return this._http.get<Hotel[]>("http://localhost:61076/api/hotel");
  }

  getHotelroomsById(id: number): Observable<Hotelroom> {
    return this._http.get<Hotelroom>("http://localhost:61076/api/hotelroom/" + id);
  }

  deleteHotelRoom(id: number): Observable<Hotelroom> {
    return this._http.delete<Hotelroom>("http://localhost:61076/api/hotelroom/" + id);
  }

  addHotelRoom(hotelroom: Hotelroom): Observable<Hotelroom> {
    return this._http.post<Hotelroom>("http://localhost:61076/api/hotelroom/", hotelroom, httpOptions);
  }

  editHotelRoom(id: number,hotelroom: Hotelroom): Observable<Hotelroom> {
    return this._http.put<Hotelroom>("http://localhost:61076/api/hotelroom/"+id, hotelroom, httpOptions);
  }
}
