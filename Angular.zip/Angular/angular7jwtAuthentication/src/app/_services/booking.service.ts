import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Customer } from '../_models/customer';
import { Booking } from '../_models/booking';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class BookingService {
 
  constructor(private _http: HttpClient) { }


  getBookings(): Observable<Booking[]> {
    return this._http.get<Booking[]>("http://localhost:61076/api/booking");
  }

  
  getCustomersById(id: number): Observable<Customer> {
    return this._http.get<Customer>("http://localhost:61076/api/customer/" + id);
  }

  getCustomers(): Observable<Customer[]> {
    return this._http.get<Customer[]>("http://localhost:61076/api/customer");
  }

  getBookingsById(id: number): Observable<Booking> {
    return this._http.get<Booking>("http://localhost:61076/api/booking/" + id);
  }

  deleteBooking(id: number): Observable<Booking> {
    return this._http.delete<Booking>("http://localhost:61076/api/booking/" + id);
  }

  addBooking(booking: Booking): Observable<Booking> {
    return this._http.post<Booking>("http://localhost:61076/api/booking/", booking, httpOptions);
  }

  editBooking(id: number,booking: Booking): Observable<Booking> {
    return this._http.put<Booking>("http://localhost:61076/api/booking/"+id, booking, httpOptions);
  }
}
