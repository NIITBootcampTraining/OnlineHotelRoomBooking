import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Hotel } from '../_models/hotel';
import { Hoteltype } from '../_models/hoteltype';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class HotelService {

  constructor(private _http: HttpClient) { }


  getHotels(): Observable<Hotel[]> {
    return this._http.get<Hotel[]>("http://localhost:61076/api//hotel");
  }

  
  getHoteltypesById(id: number): Observable<Hoteltype> {
    return this._http.get<Hoteltype>("http://localhost:61076/api//hoteltype/" + id);
  }

  getHoteltypes(): Observable<Hoteltype[]> {
    return this._http.get<Hoteltype[]>("http://localhost:61076/api//hoteltype");
  }

  getHotelsById(id: number): Observable<Hotel> {
    return this._http.get<Hotel>("http://localhost:61076/api//hotel/" + id);
  }

  deleteHotel(id: number): Observable<Hotel> {
    return this._http.delete<Hotel>("http://localhost:61076/api//hotel/" + id);
  }

  addHotel(hotel: Hotel): Observable<Hotel> {
    return this._http.post<Hotel>("http://localhost:61076/api//hotel/", hotel, httpOptions);
  }

  editHotel(id: number,hotel: Hotel): Observable<Hotel> {
    return this._http.put<Hotel>("http://localhost:61076/api//hotel/"+id, hotel, httpOptions);
  }
}
