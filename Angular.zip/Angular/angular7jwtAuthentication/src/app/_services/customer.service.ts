import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Customer } from '../_models/customer';
import { Booking } from '../_models/booking';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable()
export class CustomerService {

  constructor(private _http: HttpClient) { }


  getCustomers(): Observable<Customer[]> {
    return this._http.get<Customer[]>("http://localhost:61076/api/customer");
  }

  
  // getBookingsById(id: number): Observable<Booking> {
  //   return this._http.get<Booking>("http://localhost:58319/api/booking/" + id);
  // }

  // getBookings(): Observable<Booking[]> {
  //   return this._http.get<Booking[]>("http://localhost:58319/api/booking");
  // }

  getCustomersById(id: number): Observable<Customer> {
    return this._http.get<Customer>("http://localhost:61076/api/customer/" + id);
  }

  deleteCustomer(id: number): Observable<Customer> {
    return this._http.delete<Customer>("http://localhost:61076/api/customer/" + id);
  }

  // addCustomer(customer: Customer): Observable<Customer> {
  //   return this._http.post<Customer>("http://localhost:58319/api/customer/", customer, httpOptions);
  // }

  editCustomer(id: number,customer: Customer): Observable<Customer> {
    return this._http.put<Customer>("http://localhost:61076/api/customer/"+id, customer, httpOptions);
  }
}
