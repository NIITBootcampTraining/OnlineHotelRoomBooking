import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Hoteltype } from '../_models/hoteltype';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class HoteltypeService{

  constructor(private _http: HttpClient) { }

  getHoteltypes(): Observable<Hoteltype[]> {
    return this._http.get<Hoteltype[]>("http://localhost:61076/api/hoteltype");
  }

  getHoteltypesById(id: number): Observable<Hoteltype> {
    return this._http.get<Hoteltype>("http://localhost:61076/api/hoteltype/" + id);
  }

  deleteHotelType(id: number): Observable<Hoteltype> {
    return this._http.delete<Hoteltype>("http://localhost:61076/api/hoteltype/" + id);
  }

  addHotelType(hoteltype: Hoteltype): Observable<Hoteltype> {
    return this._http.post<Hoteltype>("http://localhost:61076/api/hoteltype/", hoteltype, httpOptions);
  }

  editHotelType(id: number,hoteltype: Hoteltype): Observable<Hoteltype> {
    return this._http.put<Hoteltype>("http://localhost:61076/api/hoteltype/"+id, hoteltype, httpOptions);
  }
}
