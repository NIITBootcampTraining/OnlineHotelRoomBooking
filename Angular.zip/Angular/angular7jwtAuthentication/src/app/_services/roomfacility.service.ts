import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Roomfacility } from '../_models/roomfacility';
import { Hotelroom } from '../_models/hotelroom';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class RoomfacilityService {

  constructor(private _http: HttpClient) { }

  getRoomfacility(): Observable<Roomfacility[]> {
    return this._http.get<Roomfacility[]>("http://localhost:61076/api/roomfacility");
  }

  getHotelrooms(): Observable<Hotelroom[]> {
    return this._http.get<Hotelroom[]>("http://localhost:61076/api/hotelroom");
  }

  getRoomfacilityById(id: number): Observable<Roomfacility> {
    return this._http.get<Roomfacility>("http://localhost:61076/api/roomfacility/" + id);
  }

  deleteRoomfacility(id: number): Observable<Roomfacility> {
    return this._http.delete<Roomfacility>("http://localhost:61076/api/roomfacility/" + id);
  }

  addRoomfacility(roomfacility: Roomfacility): Observable<Roomfacility> {
    return this._http.post<Roomfacility>("http://localhost:61076/api/roomfacility/", roomfacility, httpOptions);
  }

  editRoomfacility(id: number,roomfacility: Roomfacility): Observable<Roomfacility> {
    return this._http.put<Roomfacility>("http://localhost:61076/api/roomfacility/"+id, roomfacility, httpOptions);
  }
}
