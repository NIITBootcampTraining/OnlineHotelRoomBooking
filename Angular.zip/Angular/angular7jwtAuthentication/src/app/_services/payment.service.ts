import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Payment } from '../_models/payment'

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class PaymentService {
 
  constructor(private _http: HttpClient) { }


  getPayments(): Observable<Payment[]> {
    return this._http.get<Payment[]>("http://localhost:61076/api/payments");
  }

  getPaymentsById(id: number): Observable<Payment> {
    return this._http.get<Payment>("http://localhost:61076/api/payments/" + id);
  }
}
