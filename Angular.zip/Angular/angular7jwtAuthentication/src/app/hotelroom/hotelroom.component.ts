import { Component, OnInit } from '@angular/core';
import { Hotelroom } from '../_models/hotelroom';
import { HotelroomService } from '../_services/hotelroom.service';

@Component({
  selector: 'app-hotelroom',
  templateUrl: './hotelroom.component.html',
  styleUrls: ['./hotelroom.component.css'],
  providers: [HotelroomService]
})
export class HotelroomComponent implements OnInit {

  hotelroomList: Hotelroom[];
  constructor(private _ht: HotelroomService) { }

  ngOnInit() {
    this.getAllHotelRooms();
  }

  getAllHotelRooms() {
    this._ht.getHotelrooms().subscribe(result => {
      this.hotelroomList = result;
      console.log(this.hotelroomList);
    })
  }

  deleteExistingHotelRoom(id: number) {
    this._ht.deleteHotelRoom(id).subscribe(result => {
      console.log("HotelRoom is deleted succesfully!!");
      this.getAllHotelRooms();
    })

  }
}
