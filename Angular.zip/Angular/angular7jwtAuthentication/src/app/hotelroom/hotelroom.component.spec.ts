import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { HotelroomComponent } from './hotelroom.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { HotelroomService } from '../_services/hotelroom.service';


describe('Testing HotelRoom Component', () => {

    let component: HotelroomComponent;
    let fixture: ComponentFixture<HotelroomComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [HotelroomComponent],
            imports: [RouterTestingModule, HttpClientModule],
            providers: [HotelroomService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HotelroomComponent);
        component = fixture.componentInstance;
    })

    it('Should create', async(() => {
        expect(component).toBeTruthy();
    }))

    // it('retrieve all the HotelRooms', async(inject([HotelroomService],(HotelroomService)=>{
    //     HotelroomService.getHotelrooms().subscribe(result => {
    //         expect(result.length).toEqual(3);
    //     })
    // })))

    //     it('Delete the Hotelroom',async(inject([HotelroomService],(HotelroomService)=>{
    //         HotelroomService.deleteHotelRoom(17).subscribe(result=>{
    //        console.log('Hoteltype Deleted Successfully')
    //       })
    //   })))
})