import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router"
import { Roomfacility } from '../_models/roomfacility';
import { Hotelroom } from '../_models/hotelroom';
import { RoomfacilityService } from '../_services/roomfacility.service';
import { HotelroomService } from '../_services/hotelroom.service';

@Component({
  selector: 'app-roomfacility-detail',
  templateUrl: './roomfacility-detail.component.html',
  styleUrls: ['./roomfacility-detail.component.css'],
  providers: [RoomfacilityService,HotelroomService]
})
export class RoomfacilityDetailComponent implements OnInit {

  id: number;
  roomfacility:Roomfacility = new Roomfacility();
  rfid:number;
  hroom:Hotelroom =new Hotelroom();


  constructor(private route: ActivatedRoute,
    private _ht: RoomfacilityService, private _hr :HotelroomService, private router:Router) { }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this._ht.getRoomfacilityById(this.id).subscribe(result => {
       this.roomfacility=result;
   
       this.rfid=this.roomfacility.roomId;
       this._hr.getHotelroomsById(this.rfid).subscribe(result1 => {
       this.hroom=result1;
       })
      });
    });
  }

  deleteExistingRoomfacility(id: number) {
    this._ht.deleteRoomfacility(id).subscribe(result => {
      console.log("Roomfacility is deleted succesfully!!");
      this.router.navigate(['/roomfacility']);
    })

  }

}
