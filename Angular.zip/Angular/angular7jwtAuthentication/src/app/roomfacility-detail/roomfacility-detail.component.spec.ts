import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import{RoomfacilityDetailComponent} from './roomfacility-detail.component';
import{RouterTestingModule} from'@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { RoomfacilityService } from '../_services/Roomfacility.service';


describe('Testing RoomfacilityDetail Component', () => {
    let component: RoomfacilityDetailComponent;
    let fixture: ComponentFixture<RoomfacilityDetailComponent>;


    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [RoomfacilityDetailComponent],
            imports:[RouterTestingModule,HttpClientModule,ReactiveFormsModule],
            providers:[RoomfacilityService]
        }).compileComponents();

    }));

    beforeEach(()=>{
        fixture=TestBed.createComponent(RoomfacilityDetailComponent);
        component=fixture.componentInstance;
    })

    it('should create', () => {
      
      expect(component).toBeTruthy();

    });

    it('retrives the Roomfacility by specific id',async(inject([RoomfacilityService],(roomfacilityService)=>{
        roomfacilityService.getRoomfacilityById(7).subscribe(result=>{
           console.log('Get the Roomfacility by Id');
        })
  })
  ))

})