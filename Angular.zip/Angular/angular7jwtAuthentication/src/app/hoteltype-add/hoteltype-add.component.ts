import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Hoteltype } from '../_models/hoteltype';
import { HoteltypeService } from '../_services/hoteltype.service';

@Component({
  selector: 'app-hoteltype-add',
  templateUrl: './hoteltype-add.component.html',
  styleUrls: ['./hoteltype-add.component.css'],
  providers: [HoteltypeService]
})
export class HoteltypeAddComponent implements OnInit {

  htForm: FormGroup;
  hoteltype: Hoteltype = new Hoteltype();

  constructor(private _ht: HoteltypeService, private router: Router, private fb: FormBuilder) {
    this.createForm();
  }

  ngOnInit() {
  }

  createForm() {
    this.htForm = this.fb.group({
      hotelTypeName: ['', Validators.required],
      hotelTypeDescription: ['', Validators.required]
    });
  }

  addNewHotelType() {
    this._ht.addHotelType(this.hoteltype).subscribe(result => {
      console.log(result);
      console.log("HotelType Added Succesfully!!");
      this.router.navigate(['/hoteltype']);
    })
  }

}
