import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { HoteltypeAddComponent } from './hoteltype-add.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { Hoteltype } from '../_models/hoteltype';
import { HoteltypeService } from '../_services/hoteltype.service';


describe('Testing HotelType-Add Component', () => {

    let component: HoteltypeAddComponent;
    let fixture: ComponentFixture<HoteltypeAddComponent>;
    let hoteltype = new Hoteltype()
    {
        hoteltype.hotelTypeName = "Sea Side",
            hoteltype.hotelTypeDescription = "abc"

    };

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [HoteltypeAddComponent],
            imports: [RouterTestingModule, HttpClientModule, ReactiveFormsModule],
            providers: [HoteltypeService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HoteltypeAddComponent);
        component = fixture.componentInstance;
    })

    // it('Add HotelRooms', async(inject([HoteltypeService],(HoteltypeService)=>{
    //     HoteltypeService.addHotelType(hoteltype).subscribe(result => {
    //         console.log("Added!!");
    //     })
    // })))

})