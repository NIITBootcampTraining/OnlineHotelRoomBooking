import { Component, OnInit } from '@angular/core';
import { Roomfacility } from '../_models/roomfacility';
import { RoomfacilityService } from '../_services/roomfacility.service';


@Component({
  selector: 'app-roomfacility',
  templateUrl: './roomfacility.component.html',
  styleUrls: ['./roomfacility.component.css'],
  providers: [RoomfacilityService]
})
export class RoomfacilityComponent implements OnInit {

  roomfacilityList: Roomfacility[];

  constructor(private _h :RoomfacilityService) { }
  
  ngOnInit() {
    this.getAllRoomfacility();
  }

  getAllRoomfacility() {
    this._h.getRoomfacility().subscribe(result => {
      this.roomfacilityList = result;
      console.log(this.roomfacilityList);
    })
  }

  deleteExistingRoomfacility(id: number) {
    this._h.deleteRoomfacility(id).subscribe(result => {
      console.log("Roomfacility is deleted succesfully!!");
      this.getAllRoomfacility();
    })

  }
}
