import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { RoomfacilityComponent } from './roomfacility.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { RoomfacilityService } from '../_services/roomfacility.service';

describe('Testing Roomfacility Component', () => {

    let component: RoomfacilityComponent;
    let fixture: ComponentFixture<RoomfacilityComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [RoomfacilityComponent],
            imports: [RouterTestingModule, HttpClientModule],
            providers: [RoomfacilityService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(RoomfacilityComponent);
        component = fixture.componentInstance;
    })

    it('Should create', async(() => {
        expect(component).toBeTruthy();
    }))

    //  it('retrieve all the Roomfacility', async(inject([RoomfacilityService],(roomfacilityService)=>{
    //      roomfacilityService.getRoomfacility().subscribe(result => {
    //          expect(result.length).toEqual(2);
    //      })
    //  })))

//     it('Delete the Roomfacility',async(inject([RoomfacilityService],(RoomfacilityService)=>{
//         RoomfacilityService.deleteRoomfacility(3).subscribe(result=>{
//        console.log('Hoteltype Deleted Successfully')
//       })
//   })))
})