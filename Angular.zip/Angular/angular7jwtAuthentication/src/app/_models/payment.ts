export class Payment {
    paymentId:number;
    paymentDate:Date;
    paymentAmount:number;
    paymentDescription:string;
    customerId:number;
    bookingId:number;
}
