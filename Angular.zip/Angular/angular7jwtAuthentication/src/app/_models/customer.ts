export class Customer {
    customerId:number;
    customerFirstName:string;
    customerLastName:string;
    customerContactNumber:number;
    customerAddress:string;
    customerEmailId:string;
    country:string;
    state:string;
    zip:number;
}
