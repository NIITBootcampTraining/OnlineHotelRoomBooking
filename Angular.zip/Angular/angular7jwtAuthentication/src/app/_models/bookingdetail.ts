export class Bookingdetails {
    
}
