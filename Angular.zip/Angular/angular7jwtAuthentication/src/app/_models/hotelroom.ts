export class Hotelroom {
    roomId:number;
    roomType:string;
    roomDescription:string;
    roomPrice:number;
    roomImage:string;
    hotelId:number;
}
