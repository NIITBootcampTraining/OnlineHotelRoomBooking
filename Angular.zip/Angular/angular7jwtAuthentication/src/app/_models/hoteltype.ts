export class Hoteltype {
    hotelTypeId:number;
    hotelTypeName:string;
    hotelTypeDescription:string;
}

