export class Roomfacility {
    roomFacilityId:number;
    isAvilable:boolean;
    roomFacilityDescription:string;
    wifi:boolean;
    airConditioner:boolean;
    ekettle:boolean;
    refrigerator:boolean;
    roomId:number;
}
