export class Booking {
    bookingId:number;
    totalAmount:number;
    bookingDate:Date;
    checkIn:Date;
    checkOut:Date;
    customerId:number;
}
