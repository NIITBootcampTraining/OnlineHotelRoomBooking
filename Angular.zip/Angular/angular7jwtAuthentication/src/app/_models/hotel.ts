export class Hotel {
    hotelId:number;
    hotelName:string;
    hotelDescription:string;
    hotelAddress:string;
    hotelDistrict:string;
    hotelCity:string;
    hotelState:string;
    hotelCountry:string;
    hotelEmailId:string;
    hotelRating:number;
    hotelImage:string;
    hotelContactNumber:number;
    hotelTypeId:number;
}
