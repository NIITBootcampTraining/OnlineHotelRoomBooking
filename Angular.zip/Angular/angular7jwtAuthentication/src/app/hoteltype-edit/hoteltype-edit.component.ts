import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route } from '@angular/router';
import {Router} from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Hoteltype } from '../_models/hoteltype';
import { HoteltypeService } from '../_services/hoteltype.service';

@Component({
  selector: 'app-hoteltype-edit',
  templateUrl: './hoteltype-edit.component.html',
  styleUrls: ['./hoteltype-edit.component.css'],
  providers: [HoteltypeService]
})
export class HoteltypeEditComponent implements OnInit {

  htForm: FormGroup;
  id:number;
  hoteltype:Hoteltype = new Hoteltype();

  constructor(private _ht: HoteltypeService, private route: ActivatedRoute, private router:Router, private fb: FormBuilder) { 
    this.createForm();
  }

  ngOnInit() {
    this. getedit();
  }

  getedit(){
    this.route.params.subscribe(param =>{
      this.id = +param['id'];
      this._ht.getHoteltypesById(this.id).subscribe(result => {
        this.hoteltype = result;
      })
    })
  }

  createForm() {
    this.htForm = this.fb.group({
      hoteltypeName: ['', Validators.required],
      hoteltypeDescription: ['', Validators.required]
    });
  }

  editExistingHotelType() {
    this._ht.editHotelType(this.id,this.hoteltype).subscribe(result => {
      console.log('HotelType Updated Successfully');
      this.router.navigate(['/hoteltype']);
    })
  }

}
