import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { HoteltypeEditComponent } from './hoteltype-edit.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { Hoteltype } from '../_models/hoteltype';
import { HoteltypeService } from '../_services/hoteltype.service';


describe('Testing HotelType-Add Component', () => {

    let component: HoteltypeEditComponent;
    let fixture: ComponentFixture<HoteltypeEditComponent>;
    let hoteltype=new Hoteltype()
    {
        hoteltype.hotelTypeId=3,
        hoteltype.hotelTypeName="Sea Side",
        hoteltype.hotelTypeDescription="abcdef"
        
    };

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [HoteltypeEditComponent],
            imports: [RouterTestingModule, HttpClientModule,ReactiveFormsModule],
            providers: [HoteltypeService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HoteltypeEditComponent);
        component = fixture.componentInstance;
    })

    it('Edit HotelRooms', async(inject([HoteltypeService],(HoteltypeService)=>{
        HoteltypeService.editHotelType(3,hoteltype).subscribe(result => {
            console.log("Edited!!");
        })
    })))

})