import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookingService } from '../_services/booking.service';
import { CustomerService } from '../_services/customer.service';
import { Customer } from '../_models/customer';
import { Booking } from '../_models/booking';

@Component({
  selector: 'app-booking-detail',
  templateUrl: './booking-detail.component.html',
  styleUrls: ['./booking-detail.component.css'],
  providers:[BookingService,CustomerService]
})
export class BookingDetailComponent implements OnInit {

  id: number;
  booking:Booking = new Booking();
  htypeid:number;
  htype:Customer=new Customer();

  
  constructor(private route: ActivatedRoute,
    private _ht: BookingService,private _h:CustomerService, private router:Router) { }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this._ht.getBookingsById(this.id).subscribe(result => {
      this.booking=result;

      this.htypeid=this.booking.customerId;
      this._h.getCustomersById(this.htypeid).subscribe(result1 => {
      this.htype=result1;
      })
     });
   });
 }

  deleteExistingbooking(id: number) {
    this._ht.deleteBooking(id).subscribe(result => {
      console.log("booking is deleted succesfully!!");
      this.router.navigate(['/booking']);
    })
  }

}
