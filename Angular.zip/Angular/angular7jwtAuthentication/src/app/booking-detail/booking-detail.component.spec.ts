import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { BookingDetailComponent } from './booking-detail.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { BookingService } from '../_services/booking.service';


describe('Testing BookingDetail Component', () => {
    let component: BookingDetailComponent;
    let fixture: ComponentFixture<BookingDetailComponent>;


    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [BookingDetailComponent],
            imports: [RouterTestingModule, HttpClientModule, ReactiveFormsModule],
            providers: [BookingService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BookingDetailComponent);
        component = fixture.componentInstance;
    })

    it('should create', () => {

        expect(component).toBeTruthy();

    });

    it('retrives the Booking by specific id', async(inject([BookingService], (bookingService) => {
        bookingService.getBookingsById(3).subscribe(result => {
            console.log('Get the Booking by Id');
        })
    })
    ))

})