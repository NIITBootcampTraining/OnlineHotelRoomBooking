import { Component, OnInit } from '@angular/core';
import { Customer } from '../_models/customer';
import { Payment } from '../_models/payment';
import { ActivatedRoute, Router } from '@angular/router';
import { PaymentService } from '../_services/payment.service';
import { CustomerService } from '../_services/customer.service';

@Component({
  selector: 'app-payment-detail',
  templateUrl: './payment-detail.component.html',
  styleUrls: ['./payment-detail.component.css'],
  providers:[PaymentService,CustomerService]
})
export class PaymentDetailComponent implements OnInit {

  id: number;
  payment:Payment = new Payment();
  htypeid:number;
  htype:Customer=new Customer();

  
  constructor(private route: ActivatedRoute,
    private _ht: PaymentService,private _h:CustomerService, private router:Router) { }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this._ht.getPaymentsById(this.id).subscribe(result => {
      this.payment=result;

      this.htypeid=this.payment.customerId;
      this._h.getCustomersById(this.htypeid).subscribe(result1 => {
      this.htype=result1;
      })
     });
   });
 }
}
