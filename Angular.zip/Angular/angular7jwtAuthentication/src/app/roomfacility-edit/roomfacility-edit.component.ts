import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route } from '@angular/router';
import {Router} from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Roomfacility } from '../_models/roomfacility';
import { Hotelroom } from '../_models/hotelroom';
import { RoomfacilityService } from '../_services/roomfacility.service';

@Component({
  selector: 'app-roomfacility-edit',
  templateUrl: './roomfacility-edit.component.html',
  styleUrls: ['./roomfacility-edit.component.css'],
  providers: [RoomfacilityService]
})
export class RoomfacilityEditComponent implements OnInit {

  htForm: FormGroup;
  id:number;
  roomfacility:Roomfacility = new Roomfacility();
  hotelroomList: Hotelroom[];

  constructor(private _ht: RoomfacilityService, private route: ActivatedRoute, private router:Router,private fb: FormBuilder) { this.createForm();}

  ngOnInit() {
    this. getedit();
    this.getAllHotelRooms();
  }

  getAllHotelRooms() {
    this._ht.getHotelrooms().subscribe(result => {
      this.hotelroomList = result;
      console.log(this.hotelroomList);
    })
  } 

  createForm() {
    this.htForm = this.fb.group({
      isAvilable: ['', Validators.required],
      roomFacilityDescription: ['', Validators.required],
      wifi: ['', Validators.required],
      airConditioner: ['', Validators.required],
      ekettle: ['', Validators.required],
      refrigerator: ['', Validators.required],
      roomType: ['', Validators.required]
    });
  }

  getedit(){
    this.route.params.subscribe(param =>{
      this.id = +param['id'];
      this._ht.getRoomfacilityById(this.id).subscribe(result => {
        this.roomfacility = result;
      })
    })
  }

  editExistingRoomfacility() {
    this._ht.editRoomfacility(this.id,this.roomfacility).subscribe(result => {
      console.log('Roomfacility Updated Successfully');
      this.router.navigate(['/roomfacility']);
    })
  }

}
