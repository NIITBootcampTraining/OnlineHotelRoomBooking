import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { RoomfacilityEditComponent } from './roomfacility-edit.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { RoomfacilityService } from '../_services/roomfacility.service';
import { Roomfacility } from '../_models/roomfacility';


describe('Testing Roomfacility-Edit Component', () => {

    let component: RoomfacilityEditComponent;
    let fixture: ComponentFixture<RoomfacilityEditComponent>;
    let RoomFacility=new Roomfacility()
    {
        RoomFacility.roomFacilityId=7,
        RoomFacility.isAvilable=false,
        RoomFacility.roomFacilityDescription="desc",
        RoomFacility.wifi=true,
        RoomFacility.ekettle=false,
        RoomFacility.airConditioner=true,
        RoomFacility.refrigerator=true,
        RoomFacility.roomId=9    
    };

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [RoomfacilityEditComponent],
            imports: [RouterTestingModule, HttpClientModule,ReactiveFormsModule],
            providers: [RoomfacilityService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(RoomfacilityEditComponent);
        component = fixture.componentInstance;
    })

    it('Should create', async(() => {
        expect(component).toBeTruthy();
    }));

    it('Edit RoomFacility', async(inject([RoomfacilityService],(RoomfacilityService)=>{
        RoomfacilityService.editRoomfacility(7,RoomFacility).subscribe(result => {
            console.log("Edited!!");
        })
    })))

})