import { AboutComponent } from './about.component';

describe('Testing About Component', () => {

    it('Testing Title', () => {
        var component = new AboutComponent();
        expect(component.title).toBe('About Component');

    })
})

describe('Testing Add Function', () => {

    var component;

    beforeEach(() => {
        console.log('before-Addition');
        component = new AboutComponent();
    })

    it('Testing Positive Numbers', () => {
        expect(component.add(4, 5)).toEqual(9);
    })

    it('Testing Negative Numbers', () => {
        expect(component.add(-4, -5)).toEqual(-9);
    })

    afterEach(() => {
        console.log('after-Addition');
    })

})

describe('Testing Subtract Function', () => {

    var component;

    beforeAll(() => {
        console.log('before-Subtraction');
        component = new AboutComponent();
    })

    it('Testing Subtract 1', () => {
        expect(component.subtract(200, 100)).toEqual(100);
    })

    it('Testing Subtract 2', () => {
        expect(component.subtract(5000, 10000)).toEqual(-5000);
    })

    afterAll(() => {
        console.log('after-Subtraction');
    })
})