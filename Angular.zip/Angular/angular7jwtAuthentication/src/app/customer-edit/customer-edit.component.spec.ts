import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { CustomerEditComponent } from './customer-edit.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { Customer } from '../_models/customer';
import { CustomerService } from '../_services/customer.service';


describe('Testing Customer-Edit Component', () => {

    let component: CustomerEditComponent;
    let fixture: ComponentFixture<CustomerEditComponent>;
    let customer = new Customer()
    {
        customer.customerId = 49,
            customer.customerFirstName = 'Naman',
            customer.customerLastName = 'Malik',
            customer.customerAddress = '123 A',
            customer.state = 'Begu Sari',
            customer.country = 'India',
            customer.customerEmailId = 'abc@gmail.com',
            customer.customerContactNumber = 7552417155,
            customer.zip = 110045

    }

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [CustomerEditComponent],
            imports: [RouterTestingModule, HttpClientModule, ReactiveFormsModule],
            providers: [CustomerService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CustomerEditComponent);
        component = fixture.componentInstance;
    })

    it('Should create', async(() => {
        expect(component).toBeTruthy();
    }));

    it('Edit Customer', async(inject([CustomerService], (CustomerService) => {
        CustomerService.editCustomer(49, customer).subscribe(result => {
            console.log("Edited!!");
        })
    })))

})