import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../_services/customer.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Customer } from '../_models/customer';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-customer-edit',
  templateUrl: './customer-edit.component.html',
  styleUrls: ['./customer-edit.component.css'],
  providers: [CustomerService]
})
export class CustomerEditComponent implements OnInit {

  htForm: FormGroup;
  id:number;
  customer:Customer = new Customer();

  constructor(private _ht: CustomerService, private route: ActivatedRoute, private router:Router,private fb: FormBuilder) { this.createForm(); }

  ngOnInit() {
    this. getedit();
   
  }

  getedit(){
    this.route.params.subscribe(param =>{
      this.id = +param['id'];
      this._ht.getCustomersById(this.id).subscribe(result => {
        this.customer = result;
      })
    })
  }

  createForm() {
    this.htForm = this.fb.group({
      customerFirstName: ['', Validators.required],
      customerLastName: ['', Validators.required],
      customerAddress: ['', Validators.required],
      state: ['', Validators.required],
      country: ['', Validators.required],
      customerEmailId: ['', Validators.required],
      customerContactNumber: ['', Validators.required],
      zip: ['', Validators.required]

    });
  }
  

  editExistingCustomer() {
    this._ht.editCustomer(this.id,this.customer).subscribe(result => {
      console.log('Customer Updated Successfully');
      this.router.navigate(['/customer']);
    })
  }

}
