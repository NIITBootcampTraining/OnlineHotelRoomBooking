import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Hotelroom } from '../_models/hotelroom';
import { Hotel } from '../_models/hotel';
import { HotelroomService } from '../_services/hotelroom.service';

@Component({
  selector: 'app-hotelroom-add',
  templateUrl: './hotelroom-add.component.html',
  styleUrls: ['./hotelroom-add.component.css'],
  providers:[HotelroomService]
})
export class HotelroomAddComponent implements OnInit {

  htForm: FormGroup;
  hotelroom:Hotelroom=new Hotelroom();
  hotelList:Hotel[];

  constructor(private _ht:HotelroomService, private router:Router,private fb: FormBuilder)
   {    this.createForm(); }

  ngOnInit() {
    this.getAllHotels();

  }

  getAllHotels() {
    this._ht.getHotels().subscribe(result => {
      this.hotelList = result;
      console.log(this.hotelList);
    })
  }

  createForm() {
    this.htForm = this.fb.group({
      roomType: ['', Validators.required],
      roomDescription: ['', Validators.required],
      roomPrice: ['', Validators.required],
      roomImage: ['', Validators.required],
      hotelName: ['', Validators.required]
    });
  }

  addNewHotelRoom(){
    this._ht.addHotelRoom(this.hotelroom).subscribe(result=>{
      console.log(result);
      console.log("HotelRoom Added Succesfully!!");
      this.router.navigate(['/hotelroom']);
    })
  }
}
