import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { HotelroomAddComponent } from './hotelroom-add.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { HotelroomService } from '../_services/hotelroom.service';
import { Hotelroom } from '../_models/hotelroom';



describe('Testing HotelRoom-Add Component', () => {

    let component: HotelroomAddComponent;
    let fixture: ComponentFixture<HotelroomAddComponent>;
    let hotelroom = new Hotelroom()
    {
            hotelroom.roomType = "Sea Side",
            hotelroom.roomDescription = "abc",
            hotelroom.roomPrice = 12000,
            hotelroom.roomImage = "abc",
            hotelroom.hotelId = 3

    };

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [HotelroomAddComponent],
            imports: [RouterTestingModule, HttpClientModule, ReactiveFormsModule],
            providers: [HotelroomService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HotelroomAddComponent);
        component = fixture.componentInstance;
    })

    it('Should create', async(() => {
        expect(component).toBeTruthy();
    }));

    // it('Add HotelRooms', async(inject([HotelroomService],(HotelroomService)=>{
    //     HotelroomService.addHotelRoom(hotelroom).subscribe(result => {
    //         console.log("Added!!");
    //     })
    // })))
})