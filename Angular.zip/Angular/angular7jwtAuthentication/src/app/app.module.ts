import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

// used to create fake backend
import { fakeBackendProvider } from './_helpers';

import { AppComponent } from './app.component';
import { routing } from './app.routing';

import { JwtInterceptor, ErrorInterceptor } from './_helpers';
import { HomeComponent } from './home';
import { LoginComponent } from './login';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { HoteltypeAddComponent } from './hoteltype-add/hoteltype-add.component';
import { HoteltypeEditComponent } from './hoteltype-edit/hoteltype-edit.component';
import { HoteltypedetailComponent } from './hoteltypedetail/hoteltypedetail.component';
import { HoteltypeComponent } from './hoteltype/hoteltype.component';
import { HotelComponent } from './hotel/hotel.component';
import { HotelAddComponent } from './hotel-add/hotel-add.component';
import { HotelEditComponent } from './hotel-edit/hotel-edit.component';
import { HotelDetailComponent } from './hotel-detail/hotel-detail.component';
import { HotelroomComponent } from './hotelroom/hotelroom.component';
import { HotelroomAddComponent } from './hotelroom-add/hotelroom-add.component';
import { HotelroomDetailComponent } from './hotelroom-detail/hotelroom-detail.component';
import { HotelroomEditComponent } from './hotelroom-edit/hotelroom-edit.component';
import { RoomfacilityAddComponent } from './roomfacility-add/roomfacility-add.component';
import { RoomfacilityDetailComponent } from './roomfacility-detail/roomfacility-detail.component';
import { RoomfacilityEditComponent } from './roomfacility-edit/roomfacility-edit.component';
import { RoomfacilityComponent } from './roomfacility/roomfacility.component';
import { CustomerComponent } from './customer/customer.component';
import { CustomerEditComponent } from './customer-edit/customer-edit.component';
import { CustomerDetailComponent } from './customer-detail/customer-detail.component';
import { BookingComponent } from './booking/booking.component';
import { BookingEditComponent } from './booking-edit/booking-edit.component';
import { BookingDetailComponent } from './booking-detail/booking-detail.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentDetailComponent } from './payment-detail/payment-detail.component';


@NgModule({
    imports: [
        BrowserModule,
        ReactiveFormsModule,
        HttpClientModule,
        routing,
        FormsModule,

    ],
    declarations: [
        AppComponent,
        HomeComponent,
        LoginComponent,
        AboutComponent,
        ContactComponent,
        HoteltypeComponent,
        HoteltypeAddComponent,
        HoteltypeEditComponent,
        HoteltypedetailComponent,
        HotelComponent,
        HotelAddComponent,
        HotelEditComponent,
        HotelDetailComponent,
        HotelroomComponent,
        HotelroomAddComponent,
        HotelroomDetailComponent,
        HotelroomEditComponent,
        RoomfacilityAddComponent,
        RoomfacilityDetailComponent,
        RoomfacilityEditComponent,
        RoomfacilityComponent,
        CustomerComponent,
        CustomerEditComponent,
        CustomerDetailComponent,
        BookingComponent,
        BookingEditComponent,
        BookingDetailComponent,
        PaymentComponent,
        PaymentDetailComponent
    ],
    providers: [
        { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },

        // provider used to create fake backend
        fakeBackendProvider
    ],
    bootstrap: [AppComponent]
})

export class AppModule { }