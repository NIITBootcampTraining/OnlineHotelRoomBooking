import { Component, OnInit } from '@angular/core';
import { Hotel } from '../_models/hotel';
import { HotelService } from '../_services/hotel.service';


@Component({
  selector: 'app-hotel',
  templateUrl: './hotel.component.html',
  styleUrls: ['./hotel.component.css'],
  providers:[HotelService]
})
export class HotelComponent implements OnInit {

  hotelList: Hotel[];

  constructor(private _h :HotelService) { }
  
  ngOnInit() {
    this.getAllHotels();
  }

  getAllHotels() {
    this._h.getHotels().subscribe(result => {
      this.hotelList = result;
      console.log(this.hotelList);
    })
  }

  deleteExistingHotel(id: number) {
    this._h.deleteHotel(id).subscribe(result => {
      console.log("Hotel is deleted succesfully!!");
      this.getAllHotels();
    })

  }

}
