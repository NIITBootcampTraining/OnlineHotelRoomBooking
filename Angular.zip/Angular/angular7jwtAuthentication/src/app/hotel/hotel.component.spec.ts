import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { HotelComponent } from './hotel.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { HotelService } from '../_services/hotel.service';


describe('Testing Hotel Component', () => {

    let component: HotelComponent;
    let fixture: ComponentFixture<HotelComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [HotelComponent],
            imports: [RouterTestingModule, HttpClientModule],
            providers: [HotelService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HotelComponent);
        component = fixture.componentInstance;
    })

    it('Should create', async(() => {
        expect(component).toBeTruthy();
    }))

    // it('retrieve all the Hotels', async(inject([HotelService],(hotelService)=>{
    //     hotelService.getHotels().subscribe(result => {
    //         expect(result.length).toEqual(3);
    //     })
    // })))

    //     it('Delete the Hotel',async(inject([HotelService],(HotelService)=>{
    //         HotelService.deleteHotel(25).subscribe(result=>{
    //        console.log('Hoteltype Deleted Successfully')
    //       })
    //   })))
})