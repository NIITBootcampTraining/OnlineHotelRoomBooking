import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Roomfacility } from '../_models/roomfacility';
import { Hotelroom } from '../_models/hotelroom';
import { RoomfacilityService } from '../_services/roomfacility.service';

@Component({
  selector: 'app-roomfacility-add',
  templateUrl: './roomfacility-add.component.html',
  styleUrls: ['./roomfacility-add.component.css'],
  providers: [RoomfacilityService]
})
export class RoomfacilityAddComponent implements OnInit {

  htForm: FormGroup;
  roomfacility: Roomfacility = new Roomfacility();
  hotelroomList: Hotelroom[];

  constructor(private _rf: RoomfacilityService, private router: Router,private fb: FormBuilder) { this.createForm(); }

  ngOnInit() {
    this.getAllHotelRooms();
  }

  getAllHotelRooms() {
    this._rf.getHotelrooms().subscribe(result => {
      this.hotelroomList = result;
      console.log(this.hotelroomList);
    })
  }

  createForm() {
    this.htForm = this.fb.group({
      isAvilable: ['', Validators.required],
      roomFacilityDescription: ['', Validators.required],
      wifi: ['', Validators.required],
      airConditioner: ['', Validators.required],
      ekettle: ['', Validators.required],
      refrigerator: ['', Validators.required],
      roomType: ['', Validators.required]
    });
  }

  addNewRoomfacility() {
    this._rf.addRoomfacility(this.roomfacility).subscribe(result => {
      console.log(result);
      console.log("Roomfacility Added Succesfully!!");
      this.router.navigate(['/roomfacility']);
    })
  }
}
