import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { HotelroomDetailComponent } from './hotelroom-detail.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { HotelroomService } from '../_services/hotelroom.service';


describe('Testing HotelroomDetail Component', () => {
    let component: HotelroomDetailComponent;
    let fixture: ComponentFixture<HotelroomDetailComponent>;


    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [HotelroomDetailComponent],
            imports: [RouterTestingModule, HttpClientModule, ReactiveFormsModule],
            providers: [HotelroomService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HotelroomDetailComponent);
        component = fixture.componentInstance;
    })

    it('should create', () => {

        expect(component).toBeTruthy();

    });

    it('retrives the Hotelroom by specific id', async(inject([HotelroomService], (hotelroomService) => {
        hotelroomService.getHotelroomsById(1).subscribe(result => {
            console.log('Get the hotelroom by Id');
        })
    })
    ))

})