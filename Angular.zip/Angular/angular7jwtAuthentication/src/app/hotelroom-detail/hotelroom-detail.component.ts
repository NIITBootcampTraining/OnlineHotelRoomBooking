import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router"
import { HotelroomService } from '../_services/hotelroom.service';
import { Hotel } from '../_models/hotel';
import { Hotelroom } from '../_models/hotelroom';
import { HotelService } from '../_services/hotel.service';


@Component({
  selector: 'app-hotelroom-detail',
  templateUrl: './hotelroom-detail.component.html',
  styleUrls: ['./hotelroom-detail.component.css'],
  providers: [HotelroomService,HotelService]
})
export class HotelroomDetailComponent implements OnInit {

  id: number;
  hotelroom:Hotelroom = new Hotelroom();
  hid:number;
  ht:Hotel=new Hotel();

  constructor(private route: ActivatedRoute,
    private _ht: HotelroomService,private _h:HotelService, private router:Router) { }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this._ht.getHotelroomsById(this.id).subscribe(result => {
       this.hotelroom=result;
    
      this.hid=this.hotelroom.hotelId;
       this._h.getHotelsById(this.hid).subscribe(result1 => {
       this.ht=result1;
      })
    });
  });
}
  deleteExistingHotelRoom(id: number) {
    this._ht.deleteHotelRoom(id).subscribe(result => {
      console.log("HotelRoom is deleted succesfully!!");
      this.router.navigate(['/hotelroom']);
    })

  }
}
