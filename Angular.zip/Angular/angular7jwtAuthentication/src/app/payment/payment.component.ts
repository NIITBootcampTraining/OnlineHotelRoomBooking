import { Component, OnInit } from '@angular/core';
import { Payment } from '../_models/payment';
import { PaymentService } from '../_services/payment.service';


@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css'],
  providers:[PaymentService]
})
export class PaymentComponent implements OnInit {

  paymentList: Payment[];

  constructor(private _h : PaymentService) { }
  
  ngOnInit() {
    this.getAllPayments();
  }

  getAllPayments() {
    this._h.getPayments().subscribe(result => {
      this.paymentList = result;
      console.log(this.paymentList);
    })
  }

}
