import { Component, OnInit } from '@angular/core';
import { HoteltypeService } from '../_services/hoteltype.service';
import { Hoteltype } from '../_models/hoteltype';


@Component({
  selector: 'app-hoteltype',
  templateUrl: './hoteltype.component.html',
  styleUrls: ['./hoteltype.component.css'],
  providers: [HoteltypeService]
})
export class HoteltypeComponent implements OnInit {

  hoteltypeList: Hoteltype[];
  constructor(private _ht: HoteltypeService) { }

  ngOnInit() {
    this.getAllHotelTypes();
  }

  getAllHotelTypes() {
    this._ht.getHoteltypes().subscribe(result => {
      this.hoteltypeList = result;
      console.log(this.hoteltypeList);
    })
  }

  deleteExistingHotelType(id: number) {
    this._ht.deleteHotelType(id).subscribe(result => {
      console.log("HotelType is deleted succesfully!!");
      this.getAllHotelTypes();
    })
  }
}
