import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { HoteltypeComponent } from './hoteltype.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { Inject } from '@angular/core';
import { HoteltypeService } from '../_services/hoteltype.service';


describe('Testing HotelType Component', () => {

    let component: HoteltypeComponent;
    let fixture: ComponentFixture<HoteltypeComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [HoteltypeComponent],
            imports: [RouterTestingModule, HttpClientModule],
            providers: [HoteltypeService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HoteltypeComponent);
        component = fixture.componentInstance;
    })

    it('Should create', async(() => {
        expect(component).toBeTruthy();
    }))

    //  it('retrieve all the HotelTypes', async(inject([HoteltypeService],(hoteltypeService)=>{
    //      hoteltypeService.getHoteltypes().subscribe(result => {
    //          expect(result.length).toEqual(10);
    //      })
    //  })))

    //     it('Delete the HotelTypes',async(inject([HoteltypeService],(hoteltypeService)=>{
    //         hoteltypeService.deleteHotelType(2).subscribe(result=>{
    //        console.log('Hoteltype Deleted Successfully')
    //       })
    //   })))
})