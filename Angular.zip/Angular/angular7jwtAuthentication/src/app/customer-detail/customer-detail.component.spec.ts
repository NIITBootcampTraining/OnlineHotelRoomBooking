import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { CustomerDetailComponent } from './Customer-detail.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { CustomerService } from '../_services/Customer.service';


describe('Testing CustomerDetail Component', () => {
    let component: CustomerDetailComponent;
    let fixture: ComponentFixture<CustomerDetailComponent>;


    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [CustomerDetailComponent],
            imports: [RouterTestingModule, HttpClientModule, ReactiveFormsModule],
            providers: [CustomerService]
        }).compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CustomerDetailComponent);
        component = fixture.componentInstance;
    })

    it('should create', () => {

        expect(component).toBeTruthy();

    });

    it('retrives the Customer by specific id', async(inject([CustomerService], (customerService) => {
        customerService.getCustomersById(49).subscribe(result => {
            console.log('Get Customer by Id');
        })
    })
    ))

})