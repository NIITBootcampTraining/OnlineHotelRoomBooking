import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../_services/customer.service';
import { HotelService } from '../_services/hotel.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from '../_models/customer';
import { BookingService } from '../_services/booking.service';
import { Booking } from '../_models/booking';

@Component({
  selector: 'app-customer-detail',
  templateUrl: './customer-detail.component.html',
  styleUrls: ['./customer-detail.component.css'],
  providers: [CustomerService,BookingService]
})
export class CustomerDetailComponent implements OnInit {

  id: number;
  customer:Customer = new Customer();
  bookings:number;
  htype:Booking=new Booking();

  constructor(private route: ActivatedRoute,
    private _ht: CustomerService,private _h:BookingService, private router:Router) { }

    ngOnInit() {
      this.route.params.subscribe(param => {
      this.id = +param['id'];
      this._ht.getCustomersById(this.id).subscribe(result => {
      this.customer=result;

      this.bookings=this.customer.customerId;
      this._h.getBookingsById(this.bookings).subscribe(result1 => {
      this.htype=result1;
    })
  });
});
}

 deleteExistingCustomer(id: number) {
   this._ht.deleteCustomer(id).subscribe(result => {
     console.log("Customer is deleted succesfully!!");
     this.router.navigate(['/customer']);
   })
 }
}
